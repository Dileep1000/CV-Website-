/*Js Code for the Sticky Navigation Bar*/
const header = document.querySelector("header");
window.addEventListener("scroll", function() {

    header.classList.toggle ("sticky", window.scrollY > 100);

} )

/*Js Code for the responsiveness of the nav bar*/
let menu = document.querySelector('#menu-icon');
let NavigationBar = document.querySelector('.Nav-Bar');

menu.onclick = () => 
{
    menu.classList.toggle('bx-x');
    NavigationBar.classList.toggle('open');
}

window.onscroll = () =>
{
    menu.classList.remove('bx-x');
    NavigationBar.classList.remove('open');
}
